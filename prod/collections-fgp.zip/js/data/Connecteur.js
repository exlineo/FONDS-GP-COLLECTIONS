export class Connecteur {
    constructor() {
    }
}
